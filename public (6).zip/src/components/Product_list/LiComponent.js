import React from 'react'
import { useDispatch } from 'react-redux'
import {IncItem, setCart, setDelete} from "../../redux/cart"
import { useCart } from '../../redux/selector'

export default function LiComponent({id,img,title,description,price,disable,product,count}) {
  const dispatch = useDispatch()
  const cart = useCart()
  const handleClick = (product)=>{
        dispatch(setCart(product))
  }
  const handleDelete = (id)=>{
    dispatch(setDelete(id))
  }
  const Inc = (id) => {
    dispatch(IncItem(id))
  }
  return (
    <>
    <li className='flex mt-1 w-full h-[112px] p-2'>
    <img src={img} alt="" className={`${disable ?"":"grayscale " }`} />
       <div className='flex flex-col w-full ml-2'>
       <h1 className='font-[500] text-[16px] gont-sans'>{title}</h1>
       <p className='text-[#78716C]'>{description}</p>
         <div className='flex items-center justify-between w-full mt-auto'>
         {
          disable ?<>
          <p>€{price}</p>
       
          {
            cart.map((x)=>x.id).filter((x)=>x===id)[0] ? <div className='flex items-center'>
            <button className='bg-[#FACC15] text-[14px] py-2 px-4 rounded-[50%] mr-2'>-</button>
            <span>{count}</span>
            <button className='bg-[#FACC15] text-[14px] py-2 px-4 rounded-[50%] ml-2' onClick={()=>Inc(id)}>+</button>
            <button className='bg-[#FACC15] text-[14px] py-2 px-5 rounded-[20px] ml-2' onClick={()=>handleDelete(id)}>Delete</button>
            </div>:   <button className='bg-[#FACC15] text-[14px] py-2 px-5 rounded-[20px]' onClick={()=>handleClick(product)}>ADD TO CART</button>
          }
          </>:<>
          <p className='text-[#78716C] font-[500]'>SOLD OUT</p>
          </>
         }
         </div>
       </div>
  </li>
  <hr className='h-[5px] mt-2' />
    </>
  )
}
